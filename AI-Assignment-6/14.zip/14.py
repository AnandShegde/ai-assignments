from statistics import mode
from tkinter.messagebox import NO
import pandas as pd
import sklearn as sk
from sklearn import svm
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

data = pd.read_csv("spambase.data",header=None)

X = data.iloc[:,:-1]
scale =StandardScaler()
X=scale.fit_transform(X)


Y = data.iloc[:,-1]

X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.3,random_state=1)



c=5
model = svm.SVC(kernel="rbf",C= c)
model.fit(X_train,Y_train)
print(f"Guassian Kernal C={c} ")
print(f"Training set accuracy {model.score(X_train,Y_train)}")
model.score(X_test,Y_test)
print(f"Test Set accuracy {model.score(X_test,Y_test)}")
print("#"*40)

  

c=20
model = svm.SVC(kernel="linear",C=c)
model.fit(X_train,Y_train)
print(f"linear Kernal c={c}")
print(f"Training set accuracy {model.score(X_train,Y_train)}")
model.score(X_test,Y_test)
print(f"Test Set accuracy {model.score(X_test,Y_test)}")
print("#"*40)


c=20
model = svm.SVC(kernel="poly",C=c,degree=2)
model.fit(X_train,Y_train)
print(f"quadratic kernal c={c} ")
print(f"Training set accuracy {model.score(X_train,Y_train)}")
print(f"Test Set accuracy {model.score(X_test,Y_test)}")
print("#"*40)
