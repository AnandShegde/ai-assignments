Run the 14.py file with spambase.data in the same directory.
The program will execute and print the training and test accuracy on the terminal